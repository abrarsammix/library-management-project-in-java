package JavaLibraryMgtProject;
public class PhysicSec {
		public void  Physics_Classical_mechanics () 
		{
		 System.out.println("-=-=-=-=-=-=-=-=-=Physics_Classical_mechanics--=-=-=-=-=-=-=-=-=-");
		 System.out.println("Book Name-=-=-=-=-=-=-   Author Name=-=-=--=-=-=-=-=-=-=-=-=-");
		 String [] aat = new String [9];
		 aat [0]="Quantum Mechanics-Leonard Susskind,Art Friedman";
		 aat [1]= "Quantum Mechanics-Leonard Susskind,Art Friedman";
		 aat [2]="Classical mechanics-DE Rutherford";
		 aat [3]="Classical Mechanics Third Edition-Charles P. Poole Herbert Goldstein John";
		 aat [4]="Classical Mechanics-Richard Sparapany";
		 aat [5]="Classical Mechanics-Richard Sparapany";
		 aat [6]= "Classical Mechanics-Rana";
		 aat [7]="Advanced Quantum Mechanics by fedrikh willam";
		 aat [8]="Fundamental Principles Of Classical Mechanics by Molar";
			for(int i=0; i<7; i++)
			{
			System.out.println(aat[i]);
			}
			main main = new main();
			main.main2();
		}
		
			public  void Physics_Thermodynamics () {
				System.out.println("-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-");
				System.out.println("Book Name-=-=-=-=-=-=-   Author Name=-=-=--=-=-=-=-=-=-=-=-=-");
				String [] at = new String [7];
				at [0] ="Thermodynamics-Art Friedman";
				at [1] = "Statistical Physics for Babies-Chris Ferrie";
				at [2] = "The Four Laws That Do Not Drive the Universe-Charles P. Poole Herbert Goldstein John";
				at [3] = "The law Of Thermodynamics-Richard Sparapany";
				at [4] = "The Briefest History of Time-Arieh Ben-Naim";
				at [5] = "Time's arrow-Michael C Mackey";
				at [6] = "Information Theory-Peter Ryan";
				for(int i=0; i<7; i++)
				{
				System.out.println(at[i]);
				}
				}
				
			public  void Physics_Electromagnetism () {
				String [] bt = new String [7];
				System.out.println("-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-");
				System.out.println("Book Name-=-=-=-=-=-=-   Author Name=-=-=--=-=-=-=-=-=-=-=-=-");
				bt [0]  = "Statistical Physics for Babies-Chris Ferrie";
				bt [1]  = "The Ankh- African Origin of Electromagnetism-Nur Ankh Amen";
				bt [2]  = "No-Nonsense Electrodynamics-Jakob Schwichtenberg";
				bt [3]  = "Solved Problems in Electromagnetics-F�lix Salazar Bloise";
				bt [4]  = "Electrodynamics-Masud Chaichian";
				bt [5]  = "Neoclassical Theory of Electromagnetic Interactions-Anatoli Babin";
				bt [6]  = "Classical Electromagnetism via Relativity-W. G. V. Rosser";
				for(int j=0; j<7; j++)
				{
				System.out.println(bt[j]);
				}
				System.out.println("Thanks For Selecting Your Book"+bt[0]);
				
			}
			public  void Physics_Relative_Mechanics () {
				String [] ct = new String [7];
				System.out.println("-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-");
				System.out.println("Book Name-=-=-=-=-=-=-   Author Name=-=-=--=-=-=-=-=-=-=-=-=-");
				ct [0]  = "1. Introduction to Relativistic Statistical Mechanics-Joseph Marie";
				ct [1]  = "2. Physics-NoMen";
				ct [2]  = "3. No-Nonsense Electrodynamics-Jakob Schwichtenberg";
				ct [3]  = "4. Solved Problems in Electromagnetics-F�lix Salazar Bloise";
				ct [4]  = "5. Electrodynamics-Masud Chaichian";
				ct [5]  = "6. Neoclassical Theory of Electromagnetic Interactions-Anatoli Babin";
				ct [6]  = "7. Classical Electromagnetism via Relativity-W. G. V. Rosser";
				for(int k=0; k<7; k++)
				{
				System.out.println(ct[k]);
				}
			}

}
