package JavaLibraryMgtProject;
import java.util.Scanner;

public class main {
	

	public static void main(String[] args) 
	{
		main mainmenu = new main();
		
	  mainmenu.main2();
		
	}
	public void main2(){
		    System.out.print("\n\n\n\n\n");
		    System.out.print("\n\t\t\t  **-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**\n");
		    System.out.print("\n\t\t\t        =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=");
		    System.out.print("\n\t\t\t        =                 WELCOME                   =");
		    System.out.print("\n\t\t\t        =                   TO                      =");
		    System.out.print("\n\t\t\t        =                 LIBRARY                   =");
		    System.out.print("\n\t\t\t        =               MANAGEMENT                  =");
		    System.out.print("\n\t\t\t        =                 SYSTEM                    =");
		    System.out.print("\n\t\t\t        =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=");
		    System.out.print("\n\t\t\t  **-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**\n");

		    System.out.print("MAIN MENU");
		    System.out.print("\n\t\t\t Please Log In First ");  
		    System.out.print("\n\t\t\tPres 1 to Student Sign Up window");
		    System.out.print("\n\t\t\tPree 2 to Student Log In window");
		    System.out.print("\n\t\t\tPree 3  to Librarian Log in");
		    System.out.print("\n\n\n\t\t\tEnter choice => ");
			Scanner obj = new Scanner(System.in);
				int choice = obj.nextInt();
			
             if (choice == 1) 
				
			
             { 
			obj.nextLine();							//buffer clearing
			Module_1 obj1= new Module_1();			//calling another function
				
				System.out.println("Enter Student's Name : ");
				obj1.name=obj.nextLine();
				System.out.println("Enter Password : ");
				obj1.password=obj.nextLine();
				System.out.println("Re-Enter Password : ");
				obj1.repassword=obj.nextLine();
					if((obj1.password).equals (obj1.repassword))
					{
					System.out.println("Matched Entered Password");
					}
					else {
					System.out.println("Invalid Password");
					}
					System.out.println("\n\t\t\t We Need More info. So... ");
					System.out.println("Enter Your Father Name : ");
				obj1.fname=obj.nextLine();
				System.out.println("Enter Your university id Name : ");
				obj1.uni_id=obj.nextLine();
				System.out.println("Enter Your defined user id : ");
				obj1.uid=obj.nextLine();
				System.out.println("Enter your semester Name : ");
				obj1.sem=obj.nextInt();
				System.out.print("\n\t\tWelcome!!! Mr."+(obj1.name));
				System.out.print("\n\t\tUser:"+(obj1.uid));
				obj1.getdata(obj1.name,obj1.password,obj1.repasswordobj1,obj1.password1,obj1.repasswordobj1,obj1.fname,obj1.uni_id, obj1.uid,obj1.uid1, obj1.sem);
				System.out.print("\n\t\t\tPree 1 to View Book window");
				    
			}
             //=============================log in from=====================
			if (choice == 2) 	
			{
			obj.nextLine();							//buffer clearing
			Module_1 obj1= new Module_1();			//calling another function
				
			System.out.println("Enter User id : ");
			obj1.uid1=obj.nextLine();
			System.out.println("Enter Password : ");
			obj1.password1=obj.nextLine();
			
			if (obj1.uni_id == obj1.uid && obj1.password==obj1.password1 ){
			obj1.getdata(obj1.name,obj1.password,obj1.repasswordobj1,obj1.password1,obj1.repasswordobj1,obj1.fname,obj1.uni_id, obj1.uid,obj1.uid1, obj1.sem);
			}
				
				  System.out.print("\n\t\tWelcome!!! ");
				  System.out.print("\n\t\t\tPree 1 to View Book window");
				  System.out.print("\n\t\t\tPree 2 to go back");
				  System.out.print("\n\t\t\tPree 3 to go to Main Menu");
				  
				    
				
			}
					else 
					{
					System.out.print("\n\tInvalid Username or Password!!! ");

					}
			 //============================= librarian Log in From =======================//	
			if (choice == 3) 
			{   
				LibrarianLogIn objli= new LibrarianLogIn();	
				System.out.println("Enter Your Name : ");
				objli.li_name=obj.nextLine();
				System.out.println("Enter Password : ");
				objli.li_password=obj.nextLine();
				System.out.println("Enter University id Name : ");
				objli.li_id=obj.nextLine();
				System.out.println("Enter User id : ");
				objli.li_uid=obj.nextLine();
				objli.getdata(objli.li_name,objli.li_id,objli.li_uid,objli.li_uid1,objli.li_password,objli.li_password1);
				System.out.print("\n\t\tWelcome!!! ");
				System.out.print("\n\t\t\tPree 1 to View Book List");	
				System.out.print("\n\t\t\tPree 2 to Add Book ");
				System.out.print("\n\t\t\tPree 3 to View User ");
				
			}
			
			
			
			Scanner obj4 = new Scanner(System.in);
			int choice1 = obj.nextInt();
			if (choice1 == 1) 
			{
				
				System.out.print("\n\t\t\t\tEnter Your Dept");
				System.out.print("\n\t\tPress 1 to open Physics Dept");
				System.out.print("\n\t\tPress 2 to open Chemistry Dept ");
				System.out.print("\n\t\tPress 3 to open Biology Dept");
				System.out.print("\n\t\tPress 4 to open Mathematics Dept");
				Scanner obj5 = new Scanner(System.in);
				int choice2 = obj5.nextInt();
//====================================initiate physics department====================================//
				if (choice2 == 1) {
					System.out.print("\n\t\tWelcome to Physics Dept");
					System.out.print("\n\t\t\t\tEnter Your Dept");
					System.out.print("\n\t\tPress 1 to open Physics_Classical_mechanics");
					System.out.print("\n\t\tPress 2 to open Physics_Thermodynamics ");
					System.out.print("\n\t\tPress 3 to open Physics_Electromagnetism");
					System.out.print("\n\t\tPress 4 to open Physics_Relative_Mechanics");
					Scanner obj6 = new Scanner(System.in);
					int choice3 = obj6.nextInt();
					PhysicSec objd= new PhysicSec();
					if(choice3==1)
					{
						
					objd.Physics_Electromagnetism();	
					}
					
					if(choice3==2)
					{	
					objd.Physics_Thermodynamics();				
					}
					
					if(choice3==3)
					{
					objd.Physics_Electromagnetism();
					}
					if(choice3==4)
					{
					objd.Physics_Relative_Mechanics();				
					}	
			}
//====================================initiate chemistry department====================================//
			else if (choice2== 2) {
				System.out.print("\n\t\tWelcome to Chemistry Dept");
				System.out.print("\n\t\tPress 1 to open Analyticalchemistry");
				System.out.print("\n\t\tPress 2 to open Biochemistry ");
				System.out.print("\n\t\tPress 3 to open Physics_Electromagnetism");
				System.out.print("\n\t\tPress 4 to open Physics_Relative_Mechanics");
				ChemistrySection obj2= new ChemistrySection();
				Scanner obj7 = new Scanner(System.in);
				int choice4 = obj7.nextInt();
				if(choice4==1)
				{
				obj2.Analyticalchemistry();
				
				}
				
				if(choice4==2)
				{	
				obj2.Biochemistry();				
				}
				if(choice4==3)
				{	
				obj2.Electrochemistry();				
				}
			   	}
				
				
//====================================initiate Biology department====================================//
			else if (choice2== 4) {
				System.out.print("\n\t\tWelcome to Biology Dept");
				{
					BiologySection obj2= new BiologySection();
					Scanner obj7 = new Scanner(System.in);
					int choice4 = obj7.nextInt();
					if(choice4==1)
					{
					obj2.Biology2();	
					}
					
					if(choice4==2)
					{	
					obj2.Biology3();				
					}
					if(choice4==3)
					{	
					obj2.Biology4();				
					}
					if(choice4==4)
					{	
					obj2.Biology4();				
					}
				   	}
				
				
				
			}
				
//====================================initiate Math department====================================//

			else if (choice2== 5) {
				System.out.print("\n\t\tWelcome to Math");
				MathSection obj2= new MathSection();
				int choice5 = obj.nextInt();
				if(choice5==1)
				{
				obj2.Algebra();	
				}
				
				if(choice5==2)
				{	
				obj2.math2();				
				}
				if(choice5==3)
				{	
				obj2.math2();				
				}		
				}
				
			}
		}
	}


		
			
