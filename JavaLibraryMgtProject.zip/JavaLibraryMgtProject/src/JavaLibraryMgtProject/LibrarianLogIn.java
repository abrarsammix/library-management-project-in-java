package JavaLibraryMgtProject;
import java.util.Scanner;


public class LibrarianLogIn {
	String li_name;
	String li_id;
	String li_uid;
	String li_uid1;
	String li_password;
	String li_password1;
	
	public void getdata (String li_name,String li_id,String li_uid,String li_uid1,String li_password,String li_password1)
	{
		
		
		this.li_name=li_name;
		this.li_id=li_id;
		this.li_uid=li_uid;
		this.li_uid1=li_uid1;
		this.li_password=li_password;
		this.li_password1=li_password1;
	}
}
