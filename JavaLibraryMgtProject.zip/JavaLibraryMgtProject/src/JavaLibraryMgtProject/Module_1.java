package JavaLibraryMgtProject;

import java.util.Scanner;

public class Module_1 {
String name;
String fname;
String uni_id;
String uid;
int sem;
String uid1;
String repasswordobj1;
String password;
String password1;
String repassword;
public void getdata (String repassword,String repasswordobj1,String name,String password,String password1,String fname, String uni_id,String uid1, String uid,int sem){
	
	
	this.name=name;
	this.fname=fname;
	this.uni_id=uni_id;
	this.uid=uid;
	this.sem=sem;
	this.password=password;
	this.repasswordobj1=repasswordobj1;
	this.repassword=repassword;
	
	
	
}


public void setdata() {


}

}
