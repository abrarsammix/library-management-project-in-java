package JavaLibraryMgtProject;

public class MathSection {
	public void Algebra () {
		String [] ct = new String [7];
		System.out.println("-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-");
		System.out.println("Book Name-=-=-=-=-=-=-   Author Name=-=-=--=-=-=-=-=-=-=-=-=-");
		ct [0]  = "Principles of Algebra-Albert L. Lehninger, David L. Nelson, Michael M. Cox";
		ct [1]  = "Essentials of Biochemistry-NoMen";
		ct [2]  = "Mathematics-Jeremy M. Berg, John L. Tymoczko, Lubert L. Stryer-Jakob Schwichtenberg";
		ct [3]  = "Instant Mathematics-by S. Faiq Ahmad Shah";
		ct [4]  = "Mathematics-by Donald Voet, Judith G. Voet";
		ct [5]  = "Mathematics2-by Andrew Grey";
		ct [6]  = "Classical Mathematics-W. G. V. Rosser";
		for(int k=0; k<7; k++)
		{
		System.out.println(ct[k]);
		}
			
	}
	public  void math1 () {
		String [] at = new String [7];
		System.out.println("-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-");
		System.out.println("Book Name-=-=-=-=-=-=-   Author Name=-=-=--=-=-=-=-=-=-=-=-=-");
		at [0] ="Thermodynamics-Art Friedman";
		at [1] = "Statistical Mathematics for Babies-Chris Ferrie";
		at [2] = "The Four Laws That Do Not Drive the Universe-Charles P. Poole Herbert Goldstein John";
		at [3] = "The law Of Mathematics-Richard Sparapany";
		at [4] = "The Briefest History of Mathematics-Arieh Ben-Naim";
		at [5] = "Mathematics-Michael C Mackey";
		at [6] = "Mathematics Theory-Peter Ryan";
		for(int i=0; i<7; i++)
		{
		System.out.println(at[i]);
		}
		}
	public  void math2() {
		String [] bt = new String [7];
		System.out.println("-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-");
		System.out.println("Book Name-=-=-=-=-=-=-   Author Name=-=-=--=-=-=-=-=-=-=-=-=-");
		bt [0]  = "Statistical Mathematics-Chris Ferrie";
		bt [1]  = "The Mathematics- African Origin of Electromagnetism-Nur Ankh Amen";
		bt [2]  = "Mathematics-Nonsense Electrodynamics-Jakob Schwichtenberg";
		bt [3]  = "Solved Problems in Mathematics-F�lix Salazar Bloise";
		bt [4]  = "Electrodynamics-Masud Chaichian";
		bt [5]  = "Neoclassical Theory of Mathematics-Anatoli Babin";
		bt [6]  = "Classical Mathematics via Relativity-W. G. V. Rosser";
		for(int j=0; j<7; j++)
		{
		System.out.println(bt[j]);
		}
	}

}
