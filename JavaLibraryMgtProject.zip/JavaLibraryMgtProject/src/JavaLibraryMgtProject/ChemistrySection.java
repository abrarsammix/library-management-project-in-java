package JavaLibraryMgtProject;

public class ChemistrySection {
	public void Analyticalchemistry () {
		String [] bt = new String [7];
		bt [0]  = "Analytical Chemistry - Wan Norfazilah Wan Ismail";
		bt [1]  = "Advanced Analytical Chemistry - Nomen";
		bt [2]  = "Analytical Chemistry - Webe Celine Kadima";
		bt [3]  = "Analytical Chemistry - Dr Micheal Zehfus";
		bt [4]  = "Analytical Chemistry For Environmental Engineers And Scientists - Dr Fedeikh";
		bt [5]  = "Introduction to Instrumental Analytical Chemistry - Anatoli Babin";
		bt [6]  = "Chromatography The Most Versatile Method of Chemical Analysis-W. G. V. Rosser";
		for(int j=0; j<7; j++)
		{
		System.out.println(bt[j]);
		}
		System.out.println("Please Select you book:");
		System.out.println("You Can only Select two books at a time:");
		
		
	}
	public void Biochemistry () {
		String [] ct = new String [7];
		ct [0]  = "Principles of Biochemistry-Albert L. Lehninger, David L. Nelson, Michael M. Cox";
		ct [1]  = "Essentials of Biochemistry-NoMen";
		ct [2]  = "Biochemistry-Jeremy M. Berg, John L. Tymoczko, Lubert L. Stryer-Jakob Schwichtenberg";
		ct [3]  = "Instant Biochemistry-by S. Faiq Ahmad Shah";
		ct [4]  = "Biochemistry-by Donald Voet, Judith G. Voet";
		ct [5]  = "Biochemistry-by Andrew Grey";
		ct [6]  = "Classical Electromagnetism via Relativity-W. G. V. Rosser";
		System.out.println("Please Select you book:");
		System.out.println("You Can only Select two books at a time:");
		for(int k=0; k<7; k++)
		{
		System.out.println(ct[k]);
		}
			
	}
	public void Electrochemistry (){
		String [] dt = new String [7];
		dt [0]  = "Principles of Biochemistry-Albert L. Lehninger, David L. Nelson, Michael M. Cox";
		dt [1]  = "Essentials of Biochemistry-NoMen";
		dt [2]  = "Biochemistry-Jeremy M. Berg, John L. Tymoczko, Lubert L. Stryer-Jakob Schwichtenberg";
		dt [3]  = "Instant Biochemistry-by S. Faiq Ahmad Shah";
		dt [4]  = "Biochemistry-by Donald Voet, Judith G. Voet";
		dt [5]  = "Biochemistry-by Andrew Grey";
		dt [6]  = "Classical Electromagnetism via Relativity-W. G. V. Rosser";
		System.out.println("Please Select you book:");
		System.out.println("You Can only Select two books at a time:");
		for(int l=0; l<7; l++)
		{
		System.out.println(dt[l]);
		}
		
	}
	}
	
