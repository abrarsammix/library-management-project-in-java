package JavaLibraryMgtProject;
import java.io.File;  // Import the File class
import java.io.IOException;  // Import the IOException class to handle errors
import java.io.OutputStreamWriter;
import java.util.Scanner;
import java.io.FileWriter;

public class RegisterUnit {
	{
		System.out.println("=========Welcome To Register Unit==========");
		File myObj = new File("StudentList.txt");
	      OutputStreamWriter   myWriter = null;
		 // myWriter.write("Files in Java might be tricky, but it is fun enough!");
	    
		//myWriter.close();
		}
		
		
			
	}