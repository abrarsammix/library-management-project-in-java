package JavaLibraryMgtProject;

public class Module_2 {

	public void  Physics_Classical_mechanics () 
	{
	 System.out.println("-=-=-=-=-=-=-=-=-=-PHYSICS BOOK DETAILS GIVEN BELOW-=-=-=-=-=-=-=-=-=-");
	 System.out.println("-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-");
	 System.out.println("Quantum Mechanics-Leonard Susskind,Art Friedman");
	 System.out.println("Quantum Mechanics-Leonard Susskind,Art Friedman");
	 System.out.println("Classical mechanics-DE Rutherford");
	 System.out.println ("Classical Mechanics Third Edition-Charles P. Poole Herbert Goldstein John");
	 System.out.println ("Classical Mechanics-Richard Sparapany");
	 System.out.println ("Classical Mechanics-Richard Sparapany");
	 System.out.println ( "Classical Mechanics-Rana");
	 System.out.println	("Advanced Quantum Mechanics by fedrikh willam");
	 System.out.println	 ("Fundamental Principles Of Classical Mechanics by Molar");	
	}
	
		
		
		public  void Physics_Thermodynamics () {
			String [] pt = new String [7];
			pt [0] ="Thermodynamics-Art Friedman";
			pt [1] = "Statistical Physics for Babies-Chris Ferrie";
			pt [2] = "The Four Laws That Do Not Drive the Universe-Charles P. Poole Herbert Goldstein John";
			pt [3] = "The law Of Thermodynamics-Richard Sparapany";
			pt [4] = "The Briefest History of Time-Arieh Ben-Naim";
			pt [5] = "Time's arrow-Michael C Mackey";
			pt [6] = "Information Theory-Peter Ryan";
			for(int i=0; i<7; i++)
			{
			System.out.println(pt[i]);
			}
			}
			
		public  void Physics_Electromagnetism () {
			String Physics_Electromagnetism1 = "Statistical Physics for Babies-Chris Ferrie";
			String Physics_Electromagnetism2 = "The Ankh- African Origin of Electromagnetism-Nur Ankh Amen";
			String Physics_Electromagnetism3 = "No-Nonsense Electrodynamics-Jakob Schwichtenberg";
			String Physics_Electromagnetism4 = "Solved Problems in Electromagnetics-F�lix Salazar Bloise";
			String Physics_Electromagnetism5 = "Electrodynamics-Masud Chaichian";
			String Physics_Electromagnetism6 = "Neoclassical Theory of Electromagnetic Interactions-Anatoli Babin";
			String Physics_Electromagnetism7 = "Classical Electromagnetism via Relativity-W. G. V. Rosser";
		}
		public  void Physics_Relative_Mechanics () {
			String Physics_Relative_Mechanics1 = "Introduction to Relativistic Statistical Mechanics-Joseph Marie";
			String Physics_Relative_Mechanics2 = "-NoMen";
			String Physics_Relative_Mechanics3 = "No-Nonsense Electrodynamics-Jakob Schwichtenberg";
			String Physics_Relative_Mechanics4 = "Solved Problems in Electromagnetics-F�lix Salazar Bloise";
			String Physics_Relative_Mechanics5 = "Electrodynamics-Masud Chaichian";
			String Physics_Relative_Mechanics6 = "Neoclassical Theory of Electromagnetic Interactions-Anatoli Babin";
			String Physics_Relative_Mechanics7 = "Classical Electromagnetism via Relativity-W. G. V. Rosser";
		}
	
}
